import {
    LightningElement,
    api
} from 'lwc';

export default class BarChart extends LightningElement {
    @api chartType = 'horizontalBar';
    @api chartHeader = 'AAH Turnover sales';
    @api chartData = 17203.79;
    @api chartColors = '#B7312C';
    @api chartInfoText = 'Note: Fuel charges do not apply to AAH Hospital Services customers. You can find out more about fuel and low surcharges here';
    @api chartInfoTextLink = '';
    @api lowSurcharge = 4000;
    @api fuelSurcharge = 7500;
    formatedValue;
    formatedChartData;
    targetNameLow = 'Low surcharge';
    targetNameFuel = 'Fuel surcharge';

    renderedCallback() {
        this.formatedChartData = this.formatCurrency(Number(this.chartData), false, false);
        this.formatedValue = `£${this.formatedChartData}`

        // Get the canvas element
        const canvas = this.template.querySelector('canvas');
        if (!canvas) return
        this.drawChart()
    }
    drawChart() {
        const canvas = this.template.querySelector('canvas');
        const ctx = canvas.getContext('2d');
        const targetsHeight = 28;
        const chartBackground = 62;
        const rangeHeight = 20;
        // Set canvas dimensions
        canvas.width = 529;
        canvas.height = targetsHeight + chartBackground + rangeHeight;

        // Data for the bar chart 
        const data = Number(this.chartData);

        // Chart configuration
        const barHeight = 22;
        const chartWidth = 500; // Width of the bar
        const maxValue = data * 1.4; // Maximum value for the data

        // Draw the background
        ctx.fillStyle = '#E8F5FA';
        // ctx.fillRect(0, targetsHeight, canvas.width, canvas.height - targetsHeight - rangeHeight);
        ctx.fillRect(0, targetsHeight, canvas.width, canvas.height - targetsHeight - rangeHeight);


        // Draw the bar
        const barWidth = (data / maxValue) * chartWidth;
        ctx.fillStyle = '#B7312C';
        ctx.fillRect(0, (canvas.height - (barHeight - targetsHeight + rangeHeight)) / 2, barWidth, barHeight);

        // Draw the targtets
        this.drawTargetPoint(ctx, this.targetNameLow, this.lowSurcharge, maxValue, chartWidth, targetsHeight, canvas.height);
        this.drawTargetPoint(ctx, this.targetNameFuel, this.fuelSurcharge, maxValue, chartWidth, targetsHeight, canvas.height);


        // Draw the scale text
        this.drawScale(ctx, maxValue, chartWidth, targetsHeight, canvas.height, rangeHeight, chartBackground);
    }


    drawTargetPoint(ctx, targetName, targetValue, maxValue, chartWidth, targetsHeight, canvasHeight) {
        const xPosition = (targetValue / maxValue) * chartWidth;
        const fillColor = '#1B9FD0'
        ctx.strokeStyle = fillColor;
        ctx.lineWidth = 3;

        ctx.beginPath();
        ctx.moveTo(xPosition, targetsHeight - 6);
        ctx.lineTo(xPosition, canvasHeight - targetsHeight + 8);
        ctx.stroke();

        ctx.fillStyle = fillColor;

        const textWidth = ctx.measureText(targetName).width;
        const padding = 4;
        const borderRadius = 10;
        const rectWidth = textWidth + 2 * padding;
        const rectHeight = 16 + padding;
        const rectX = xPosition - rectWidth / 2;
        const rectY = targetsHeight + 6 - rectHeight - 12;

        ctx.beginPath();
        ctx.moveTo(rectX + borderRadius, rectY);
        ctx.lineTo(rectX + rectWidth - borderRadius, rectY);
        ctx.quadraticCurveTo(rectX + rectWidth, rectY, rectX + rectWidth, rectY + borderRadius);
        ctx.lineTo(rectX + rectWidth, rectY + rectHeight - borderRadius);
        ctx.quadraticCurveTo(rectX + rectWidth, rectY + rectHeight, rectX + rectWidth - borderRadius, rectY + rectHeight);
        ctx.lineTo(rectX + borderRadius, rectY + rectHeight);
        ctx.quadraticCurveTo(rectX, rectY + rectHeight, rectX, rectY + rectHeight - borderRadius);
        ctx.lineTo(rectX, rectY + borderRadius);
        ctx.quadraticCurveTo(rectX, rectY, rectX + borderRadius, rectY);
        ctx.closePath();
        ctx.fill();

        // Draw the top label
        ctx.fillStyle = '#fff';
        ctx.font = '12px Open Sans';
        ctx.letterSpacing = '0.5px'; // Set letter spacing
        ctx.fillText(targetName, xPosition - textWidth / 2, rectY + rectHeight / 2 + 3);

        // Draw the bottom label
        ctx.fillStyle = '#595959';
        ctx.font = '12px system-ui';
        const targetValueText = this.formatCurrency(targetValue, true)
        const targetValueTextWidth = ctx.measureText(targetValueText).width;
        const targetValueY = canvasHeight - targetsHeight + 26;

        ctx.fillText(`£${targetValueText}`, xPosition - targetValueTextWidth / 2, targetValueY);

        // Draw the connecting line from the center of the number to the target line
        ctx.strokeStyle = '#595959';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(xPosition, targetValueY - 18); // Starting point (center of the number)
        ctx.lineTo(xPosition, targetValueY - 12); // End point (6px above the starting point)
        ctx.stroke();
    }


    drawScale(ctx, maxValue, chartWidth, targetsHeight, canvasHeight, rangeHeight, chartBackground) {
        const step = 5000;
        ctx.fillStyle = '#595959';
        ctx.font = '12px system-ui';
        ctx.textAlign = 'center';

        for (let value = step; value <= maxValue; value += step) {
            const scaleValue = this.formatCurrency(value, true)
            const xPosition = (value / maxValue) * chartWidth;
            ctx.fillText(`£${scaleValue}`, xPosition, canvasHeight - targetsHeight + rangeHeight + 6);
            ctx.beginPath();
            ctx.moveTo(xPosition, targetsHeight + chartBackground);
            ctx.lineTo(xPosition, canvasHeight - targetsHeight + rangeHeight - 6);
            ctx.strokeStyle = '#595959';
            ctx.lineWidth = 3;
            ctx.stroke();
        }
    }

    formatCurrency(amount, useAbbreviations = false, isCenter = false) {
        let formattedAmount;

        if (useAbbreviations) {
            if (amount > 999999) {
                formattedAmount = Math.floor(amount / 1000000) + 'M';
            } else if (amount >= 1_000) {
                formattedAmount = Math.floor(amount / 1000) + 'K';
            } else {
                formattedAmount = Math.floor(amount).toString();
            }
        } else {
            if (isCenter) {
                formattedAmount = Math.floor(amount).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            } else {
                formattedAmount = amount.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
            }
        }

        return formattedAmount;
    }
}